# ROMANCE ROYAL — Luxury Store Demo

This is a responsive HTML/CSS/JS storefront matching the Romance Royal luxury visual direction.

## Replace the image placeholders

Put your own images inside `/assets/` using these exact filenames:

- hero.jpg
- category-lingerie.jpg
- category-fantasy.jpg
- category-nightwear.jpg
- category-shapewear.jpg
- category-bodysuit.jpg
- category-crop.jpg
- collection-banner.jpg
- product-1.jpg
- product-2.jpg
- product-3.jpg
- product-4.jpg
- product-5.jpg
- product-6.jpg
- editorial.jpg

No code changes are required if you keep those filenames.

## Run

Open `index.html` directly in a browser, or use VS Code Live Server.

## Included

- Luxury responsive homepage
- Desktop + mobile layout
- Header/navigation
- Hero section
- Product categories
- Collection banner
- Featured product cards
- Wishlist visual interaction
- Working cart drawer with localStorage
- Search panel
- Editorial banner
- About section
- Footer/newsletter
